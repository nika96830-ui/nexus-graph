import test from "node:test";
import assert from "node:assert/strict";
import fs from "node:fs";
import path from "node:path";
import { createRequire } from "node:module";

const require = createRequire(import.meta.url);
const { LIMITS, validateGraphData, parseAndValidateJson } = require("../app.js");

test("accepts valid graph JSON", () => {
  const res = parseAndValidateJson(JSON.stringify({
    nodes: [{ id: "a", name: "Node A", group: "core", size: 16, desc: "Desc" }, { id: "b" }],
    links: [{ source: "a", target: "b", label: "edge" }]
  }));
  assert.equal(res.ok, true);
  assert.equal(res.data.nodes.length, 2);
  assert.equal(res.data.links.length, 1);
  assert.equal(res.data.nodes[1].size, LIMITS.DEFAULT_NODE_SIZE);
});

test("rejects non-object, missing arrays, and empty nodes", () => {
  assert.equal(validateGraphData(null).ok, false);
  assert.equal(validateGraphData([]).ok, false);
  assert.equal(validateGraphData({ nodes: {}, links: [] }).ok, false);
  assert.equal(validateGraphData({ nodes: [], links: [] }).ok, false);
});

test("deduplicates nodes, filters orphan links, and clamps size", () => {
  const res = validateGraphData({
    nodes: [
      { id: "a", size: 999 },
      { id: "a", size: 10 },
      { id: "b", size: -5 },
      { id: "" }
    ],
    links: [
      { source: "a", target: "b" },
      { source: "a", target: "missing_node" }
    ]
  });
  assert.equal(res.ok, true);
  assert.equal(res.data.nodes.length, 2);
  assert.equal(res.data.nodes[0].size, LIMITS.MAX_NODE_SIZE);
  assert.equal(res.data.nodes[1].size, LIMITS.MIN_NODE_SIZE);
  assert.equal(res.data.links.length, 1);
  assert.equal(res.stats.droppedDuplicateNodes, 1);
  assert.equal(res.stats.droppedInvalidNodes, 1);
  assert.equal(res.stats.droppedOrphanLinks, 1);
});

test("enforces node and link count limits", () => {
  const tooManyNodes = Array.from({ length: LIMITS.MAX_NODES + 1 }, (_, i) => ({ id: "n" + i }));
  assert.equal(validateGraphData({ nodes: tooManyNodes, links: [] }).ok, false);
});

test("keeps XSS payload as plain data and app.js never uses innerHTML", () => {
  const payload = '<img src=x onerror="alert(1)">';
  const res = validateGraphData({
    nodes: [{ id: payload, name: payload, group: payload, desc: payload }],
    links: []
  });
  assert.equal(res.ok, true);
  assert.equal(res.data.nodes[0].desc, payload);

  const appCode = fs.readFileSync(path.resolve("app.js"), "utf8");
  assert.equal(appCode.includes("innerHTML"), false, "app.js must not use innerHTML");
  assert.equal(appCode.includes("d3.timer("), false, "app.js must not use infinite d3.timer");
});
